SYNTHETIC TEST CONTENT ONLY: assets/index.esm-DR6eTzAd.js
