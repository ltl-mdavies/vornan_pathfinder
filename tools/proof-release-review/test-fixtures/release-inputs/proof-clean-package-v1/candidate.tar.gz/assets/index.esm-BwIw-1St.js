SYNTHETIC TEST CONTENT ONLY: assets/index.esm-BwIw-1St.js
