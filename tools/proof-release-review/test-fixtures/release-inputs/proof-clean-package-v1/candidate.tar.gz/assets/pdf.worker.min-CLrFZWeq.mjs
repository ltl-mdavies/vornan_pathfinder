SYNTHETIC TEST CONTENT ONLY: assets/pdf.worker.min-CLrFZWeq.mjs
