SYNTHETIC TEST CONTENT ONLY: assets/index.esm-Cyk35PyT.js
