SYNTHETIC TEST CONTENT ONLY: assets/pdf-worker-url-B-4I8zKO.js
