SYNTHETIC TEST CONTENT ONLY: assets/index-BLpayhdw.js
